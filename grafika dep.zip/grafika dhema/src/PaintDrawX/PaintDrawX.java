/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PaintDrawX;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Stack;
import javax.imageio.ImageIO;

/**
 *
 * @author dhema
 */

public class PaintDrawX extends JFrame {
    private DrawArea drawArea;
    private JButton clearBtn, saveBtn, colorBtn, undoBtn, redoBtn, eraserBtn;
    private JComboBox<String> shapeSelector;
    private JSlider sizeSlider;
    private Color currentColor = Color.BLACK;
    private boolean erasing = false;

    public PaintDrawX() {
        setTitle("PaintDrawX - Grafika Komputer");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        drawArea = new DrawArea();
        add(drawArea, BorderLayout.CENTER);

        JPanel controlPanel = new JPanel();

        colorBtn = new JButton("Warna");
        clearBtn = new JButton("Clear");
        saveBtn = new JButton("Simpan");
        undoBtn = new JButton("Undo");
        redoBtn = new JButton("Redo");
        eraserBtn = new JButton("Eraser");

        shapeSelector = new JComboBox<>(new String[]{"Freehand", "Garis", "Persegi", "Lingkaran"});
        sizeSlider = new JSlider(1, 20, 5);
        sizeSlider.setMajorTickSpacing(5);
        sizeSlider.setPaintTicks(true);
        sizeSlider.setPaintLabels(true);

        controlPanel.add(colorBtn);
        controlPanel.add(eraserBtn);
        controlPanel.add(new JLabel("Bentuk:"));
        controlPanel.add(shapeSelector);
        controlPanel.add(new JLabel("Ukuran:"));
        controlPanel.add(sizeSlider);
        controlPanel.add(undoBtn);
        controlPanel.add(redoBtn);
        controlPanel.add(clearBtn);
        controlPanel.add(saveBtn);

        add(controlPanel, BorderLayout.NORTH);

        // Event listeners
        colorBtn.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(null, "Pilih Warna", currentColor);
            if (newColor != null) {
                currentColor = newColor;
                drawArea.setColor(currentColor);
                erasing = false;
            }
        });

        eraserBtn.addActionListener(e -> {
            drawArea.setColor(Color.WHITE);
            erasing = true;
        });

        clearBtn.addActionListener(e -> drawArea.clear());
        saveBtn.addActionListener(e -> drawArea.saveImage());
        undoBtn.addActionListener(e -> drawArea.undo());
        redoBtn.addActionListener(e -> drawArea.redo());
        shapeSelector.addActionListener(e -> drawArea.setShape((String) shapeSelector.getSelectedItem()));
        sizeSlider.addChangeListener(e -> drawArea.setBrushSize(sizeSlider.getValue()));

        setVisible(true);
    }

    class DrawArea extends JPanel {
        private BufferedImage image;
        private Graphics2D g2;
        private int startX, startY, endX, endY;
        private String currentShape = "Freehand";
        private Stack<BufferedImage> undoStack = new Stack<>();
        private Stack<BufferedImage> redoStack = new Stack<>();
        private int brushSize = 5;

        public DrawArea() {
            setBackground(Color.WHITE);
            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    saveToUndoStack();
                    startX = e.getX();
                    startY = e.getY();
                    if (currentShape.equals("Freehand")) {
                        g2.fillOval(startX, startY, brushSize, brushSize);
                        repaint();
                    }
                }

                public void mouseReleased(MouseEvent e) {
                    if (!currentShape.equals("Freehand")) {
                        endX = e.getX();
                        endY = e.getY();
                        drawShape(startX, startY, endX, endY);
                        repaint();
                    }
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    if (currentShape.equals("Freehand")) {
                        g2.fillOval(e.getX(), e.getY(), brushSize, brushSize);
                        repaint();
                    }
                }
            });
        }

        protected void paintComponent(Graphics g) {
            if (image == null) {
                image = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
                g2 = image.createGraphics();
                g2.setColor(Color.WHITE);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(currentColor);
            }
            g.drawImage(image, 0, 0, null);
        }

        public void setColor(Color c) {
            currentColor = c;
            g2.setColor(c);
        }

        public void setShape(String shape) {
            currentShape = shape;
        }

        public void setBrushSize(int size) {
            brushSize = size;
            g2.setStroke(new BasicStroke(size));
        }

        public void clear() {
            saveToUndoStack();
            g2.setColor(Color.WHITE);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setColor(currentColor);
            repaint();
        }

        public void drawShape(int x1, int y1, int x2, int y2) {
            g2.setColor(currentColor);
            switch (currentShape) {
                case "Garis":
                    g2.drawLine(x1, y1, x2, y2);
                    break;
                case "Persegi":
                    g2.drawRect(Math.min(x1, x2), Math.min(y1, y2),
                            Math.abs(x2 - x1), Math.abs(y2 - y1));
                    break;
                case "Lingkaran":
                    g2.drawOval(Math.min(x1, x2), Math.min(y1, y2),
                            Math.abs(x2 - x1), Math.abs(y2 - y1));
                    break;
            }
        }

        public void saveImage() {
            try {
                JFileChooser chooser = new JFileChooser();
                if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
                    File file = chooser.getSelectedFile();
                    ImageIO.write(image, "PNG", file);
                    JOptionPane.showMessageDialog(null, "Gambar berhasil disimpan!");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        public void undo() {
            if (!undoStack.isEmpty()) {
                redoStack.push(copyImage(image));
                image = undoStack.pop();
                g2 = image.createGraphics();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(currentColor);
                g2.setStroke(new BasicStroke(brushSize));
                repaint();
            }
        }

        public void redo() {
            if (!redoStack.isEmpty()) {
                undoStack.push(copyImage(image));
                image = redoStack.pop();
                g2 = image.createGraphics();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(currentColor);
                g2.setStroke(new BasicStroke(brushSize));
                repaint();
            }
        }

        private void saveToUndoStack() {
            undoStack.push(copyImage(image));
            redoStack.clear();
        }

        private BufferedImage copyImage(BufferedImage img) {
            BufferedImage copy = new BufferedImage(img.getWidth(), img.getHeight(), img.getType());
            Graphics2D g = copy.createGraphics();
            g.drawImage(img, 0, 0, null);
            g.dispose();
            return copy;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PaintDrawX::new);
    }
}
